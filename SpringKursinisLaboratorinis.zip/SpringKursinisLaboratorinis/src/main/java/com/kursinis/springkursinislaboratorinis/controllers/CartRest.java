package com.kursinis.springkursinislaboratorinis.controllers;

import com.kursinis.springkursinislaboratorinis.errors.CartNotFound;
import com.kursinis.springkursinislaboratorinis.model.Cart;
import com.kursinis.springkursinislaboratorinis.repos.CartRepository;
import com.kursinis.springkursinislaboratorinis.repos.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
public class CartRest {

    @Autowired
    private CartRepository cartRepository;

    @GetMapping(value = "/getAllCartItems")
    public @ResponseBody Iterable<Cart> getAllCartItems(){
        return cartRepository.findAll();
    }

    @PostMapping(value = "/addToCart")
    public @ResponseBody Cart addToCart(@RequestBody Cart cart){
        return cartRepository.saveAndFlush(cart);
    }

    @PutMapping(value = "/updateCartItem")
    public @ResponseBody Optional<Cart> updateCartItem(@RequestBody Cart cart){
        cartRepository.save(cart);
        return cartRepository.findById(cart.getId());
    }

    @DeleteMapping(value = "/removeFromCart/{id}")
    public @ResponseBody String removeFromCart(@PathVariable int id){
        cartRepository.deleteById(id);
        return "Item removed from the cart";
    }

    @GetMapping(value = "/getCartItemById/{id}")
    public EntityModel<Cart> getCartItemById(@PathVariable int id){
        Cart cart = cartRepository.findById(id).orElseThrow();
        return EntityModel.of(cart, linkTo(methodOn(CartRest.class, getCartItemById(id))).withSelfRel(), linkTo(methodOn(CartRest.class, getAllCartItems())).withRel("CartItems"));
    }

}
