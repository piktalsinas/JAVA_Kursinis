package com.kursinis.springkursinislaboratorinis.controllers;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.kursinis.springkursinislaboratorinis.errors.UserNotFound;
import com.kursinis.springkursinislaboratorinis.model.User;
import com.kursinis.springkursinislaboratorinis.repos.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
//import com.google.gson.Gson;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
public class UserRest {

    @Autowired
    private UserRepository userRepository;

    @GetMapping(value ="/getAllUsers")
    public @ResponseBody Iterable<User> getAllUsers(){
        return userRepository.findAll();
    }

//    @PostMapping(value ="/insertUserFull")
//    public @ResponseBody User saveUser(@RequestBody User user){
//        return userRepository.saveAndFlush(user);
//    }

    @PostMapping(value = "/insertUser")
    public ResponseEntity<User> insertUser(@RequestBody User user) {
    User savedUser = userRepository.saveAndFlush(user);
    return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
}


//    @PutMapping(value="updateUser")
//    public @ResponseBody Optional<User> updateUser(@RequestBody User user){
//        userRepository.save(user);
//        return userRepository.findById(user.getId());
//    }

    @CrossOrigin
    @PutMapping(value = "/updateUser")
    public ResponseEntity<User> updateUser(@RequestBody User user) {
        Optional<User> existingUserOptional = userRepository.findById(user.getId());

        if (existingUserOptional.isPresent()) {
            User existingUser = existingUserOptional.get();

            existingUser.setLogin(user.getLogin());
            existingUser.setPassword(user.getPassword());

            userRepository.save(existingUser);

            return ResponseEntity.ok(existingUser);
        } else {

            return ResponseEntity.notFound().build();
        }
    }
//    @PutMapping("/updateUser/{id}")
//    public ResponseEntity<User> updateUserCredentials(@PathVariable int id, @RequestBody User updatedCredentials) {
//        try {
//            Optional<User> optionalUser = userRepository.findById(id);
//
//            if (optionalUser.isPresent()) {
//                User existingUser = optionalUser.get();
//                updateExistingUser(existingUser, updatedCredentials);
//                userRepository.save(existingUser);
//
//                return ResponseEntity.ok(existingUser);
//            } else {
//                return ResponseEntity.notFound().build();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
//        }
//    }
//    private void updateExistingUser(User existingUser, User updatedCredentials) {
//
//        existingUser.setLogin(updatedCredentials.getLogin());
//        existingUser.setPassword(updatedCredentials.getPassword());
//    }

    @DeleteMapping(value="deleteUser/{id}")
    public @ResponseBody String deleteUser(@PathVariable int id){
        userRepository.deleteById(id);
        return "user deleted";
    }


    @GetMapping(value = "/getUserById/{id}")
    public EntityModel<User> one(@PathVariable int id) {
    User user = userRepository.findById(id).orElseThrow(() -> new UserNotFound(id));
    Link selfLink = linkTo(UserRest.class).slash("getUserById").slash(id).withSelfRel();
    return EntityModel.of(user, selfLink, linkTo(methodOn(UserRest.class).getAllUsers()).withRel("Users"));
    }



    @PostMapping(value = "/getUserByCredentials")
    public ResponseEntity<User> getUserByCredentials(@RequestBody String requestBody) {
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(requestBody, JsonObject.class);

        String login = jsonObject.get("login").getAsString();
        String password = jsonObject.get("password").getAsString();

        Optional<User> optionalUser = userRepository.findByLoginAndPassword(login, password);

        if (optionalUser.isPresent()) {
            return new ResponseEntity<>(optionalUser.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }




}
