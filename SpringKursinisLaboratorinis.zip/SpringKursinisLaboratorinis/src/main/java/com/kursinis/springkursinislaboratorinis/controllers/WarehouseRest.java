package com.kursinis.springkursinislaboratorinis.controllers;

import com.kursinis.springkursinislaboratorinis.errors.WarehouseNotFound;
import com.kursinis.springkursinislaboratorinis.model.Warehouse;
import com.kursinis.springkursinislaboratorinis.model.Warehouse;
import com.kursinis.springkursinislaboratorinis.repos.WarehouseRepository;
import com.kursinis.springkursinislaboratorinis.repos.WarehouseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
public class WarehouseRest {
    @Autowired
    private WarehouseRepository warehouseRepository;

    @GetMapping(value ="/getAllWarehouses")
    public @ResponseBody Iterable<Warehouse> getAllWarehouses(){
        return warehouseRepository.findAll();
    }

    @PostMapping(value ="/insertWarehouseFull")
    public @ResponseBody Warehouse saveWarehouse(@RequestBody Warehouse warehouse){
        return warehouseRepository.saveAndFlush(warehouse);
    }

    @PutMapping(value="updateWarehouse")
    public @ResponseBody Optional<Warehouse> updateWarehouse(@RequestBody Warehouse warehouse){
        warehouseRepository.save(warehouse);
        return warehouseRepository.findById(warehouse.getId());
    }

    @DeleteMapping(value="deleteWarehouse/{id}")
    public @ResponseBody String deleteWarehouse(@PathVariable int id){
        warehouseRepository.deleteById(id);
        return "Warehouse deleted";
    }

    @GetMapping(value="getWarehouseById/{id}")
    public EntityModel<Warehouse> one(@PathVariable int id){
        Warehouse warehouse = warehouseRepository.findById(id).orElseThrow(()-> new WarehouseNotFound(id));
        return EntityModel.of(warehouse, linkTo(methodOn(WarehouseRest.class, one(id))).withSelfRel(), linkTo(methodOn(WarehouseRest.class, getAllWarehouses())).withRel("Warehouses"));
    }
}
