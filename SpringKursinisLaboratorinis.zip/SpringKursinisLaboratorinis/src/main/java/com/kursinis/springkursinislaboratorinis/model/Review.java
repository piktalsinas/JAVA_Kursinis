package com.kursinis.springkursinislaboratorinis.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Review {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
   // @JoinColumn(name = "product_id")
    private Product product;

    @ManyToOne
   // @JoinColumn(name = "customer_id")
    private Customer customer;
    @ManyToOne
    // @JoinColumn(name = "employee_id")
    private Employee employee;

    private String reviewBody;

//    public String getUserLogin() {
//        return customer != null ? customer.getLogin() : null;
//    }
public String getUserLogin() {
    if (customer != null) {
        return customer.getLogin();
    } else if (employee != null) {
        return employee.getLogin();
    } else {
        return null;
    }
}

    @OneToMany(mappedBy = "originalReview", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private List<Review> replies = new ArrayList<>();


    @ManyToOne
    private Review originalReview;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

}
