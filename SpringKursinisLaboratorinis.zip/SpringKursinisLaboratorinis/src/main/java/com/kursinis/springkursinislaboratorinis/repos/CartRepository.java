package com.kursinis.springkursinislaboratorinis.repos;

import com.kursinis.springkursinislaboratorinis.model.Cart;
import com.kursinis.springkursinislaboratorinis.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartRepository extends JpaRepository<Cart, Integer> {
}
