package com.kursinis.springkursinislaboratorinis.model;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Candy extends Product {
    private String sugarProps;
    private String weight;

    public Candy(String title, String description, String sugarProps, String weight) {
        super(title, description);
        this.sugarProps = sugarProps;
        this.weight = weight;
    }
}
