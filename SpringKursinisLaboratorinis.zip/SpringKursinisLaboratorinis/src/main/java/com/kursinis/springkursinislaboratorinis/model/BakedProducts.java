package com.kursinis.springkursinislaboratorinis.model;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
public class BakedProducts extends Product {

//    private LocalDate bakedDate;
//
//    public BakedProducts(String title, String description, LocalDate bakedDate) {
//        super(title, description);
//        this.bakedDate = bakedDate;
//    }
//
    public String toString() {

        return "Product: " + getTitle() + ", Description: " + getDescription();
    }

    private LocalDate bakedDate;

    public BakedProducts(String title, String description, LocalDate bakedDate) {
        super(title, description);
        this.bakedDate = bakedDate;
    }

    public BakedProducts(String title, String description, Warehouse warehouse, LocalDate plantDate) {
        super(title, description, warehouse);
        this.bakedDate = bakedDate;
    }
}
