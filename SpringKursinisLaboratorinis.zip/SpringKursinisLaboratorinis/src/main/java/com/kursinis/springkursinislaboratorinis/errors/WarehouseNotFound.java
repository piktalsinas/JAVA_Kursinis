package com.kursinis.springkursinislaboratorinis.errors;

public class WarehouseNotFound  extends RuntimeException{
    public WarehouseNotFound(int id){
        super("Product not found by Id" + id);
    }
}
