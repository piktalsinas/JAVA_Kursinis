package com.kursinis.springkursinislaboratorinis.model;

public enum ProductType {
    BAKEDPRODUCTS, OTHER, CANDY;

}