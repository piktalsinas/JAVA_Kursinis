package com.kursinis.springkursinislaboratorinis.errors;

public class ProductNotFound extends RuntimeException {

    public ProductNotFound(int id){
        super("Product not found by Id" + id);
    }
}
