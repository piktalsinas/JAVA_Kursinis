package com.kursinis.springkursinislaboratorinis.controllers;

import com.kursinis.springkursinislaboratorinis.errors.ProductNotFound;
import com.kursinis.springkursinislaboratorinis.model.Product;
import com.kursinis.springkursinislaboratorinis.model.Product;
import com.kursinis.springkursinislaboratorinis.repos.ProductRepository;
import com.kursinis.springkursinislaboratorinis.repos.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
public class ProductRest {
    @Autowired
    private ProductRepository productRepository;

    @GetMapping(value ="/getAllProducts")
    public @ResponseBody Iterable<Product> getAllProducts(){
        return productRepository.findAll();
    }

    @PostMapping(value ="/insertProductFull")
    public @ResponseBody Product saveProduct(@RequestBody Product product){
        return productRepository.saveAndFlush(product);
    }

    @PutMapping(value="updateProduct")
    public @ResponseBody Optional<Product> updateProduct(@RequestBody Product product){
        productRepository.save(product);
        return productRepository.findById(product.getId());
    }

    @DeleteMapping(value="deleteProduct/{id}")
    public @ResponseBody String deleteProduct(@PathVariable int id){
        productRepository.deleteById(id);
        return "Product deleted";
    }

//    @GetMapping(value="getProductById/{id}")
//    public EntityModel<Product> one(@PathVariable int id){
//        Product product = productRepository.findById(id).orElseThrow(()-> new ProductNotFound(id));
//        return EntityModel.of(product, linkTo(methodOn(ProductRest.class, one(id))).withSelfRel(), linkTo(methodOn(ProductRest.class, getAllProducts())).withRel("Products"));
//    }

    @GetMapping("/getProductById/{id}")
    public ResponseEntity<EntityModel<Product>> getProductById(@PathVariable int id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ProductNotFound(id));

        Link selfLink = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(ProductRest.class).getProductById(id)).withSelfRel();
        Link productsLink = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(ProductRest.class).getAllProducts()).withRel("Products");

        EntityModel<Product> entityModel = EntityModel.of(product, selfLink, productsLink);

        return ResponseEntity.ok(entityModel);
    }
}
