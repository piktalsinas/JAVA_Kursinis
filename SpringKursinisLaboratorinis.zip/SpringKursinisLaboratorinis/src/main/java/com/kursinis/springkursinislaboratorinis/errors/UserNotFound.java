package com.kursinis.springkursinislaboratorinis.errors;

public class UserNotFound extends RuntimeException{
    public UserNotFound(int id){
        super("User not found by Id" + id);
    }
}
