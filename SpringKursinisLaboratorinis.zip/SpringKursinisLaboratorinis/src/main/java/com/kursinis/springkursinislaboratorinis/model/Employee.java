package com.kursinis.springkursinislaboratorinis.model;

import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Employee extends User {

//    private String employeeId;
//    private String medCertificate;
    private LocalDate employmentDate;
   // private boolean isAdmin;
    @ManyToOne
    private Warehouse worksInWarehouse;

    public Employee(String login, String password, LocalDate birthDate, String name, String surname, LocalDate employmentDate) {
        super(login, password, birthDate, name, surname);
        this.employmentDate=employmentDate;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "login='" + login + '\'' +
                ", password='" + password + '\'' +
                ", birthdate='" + birthDate + '\'' +
                ", name='" + name + '\'' +
                ", surname=" + surname + '\'' +
                ", employmentDate=" + employmentDate +
                '}';
    }
}
