package com.kursinis.springkursinislaboratorinis.errors;

public class CartNotFound  extends RuntimeException {
//    public CartNotFound(int id) {
//        "Cart not found by Id";
//    }
}
