package com.kursinis.springkursinislaboratorinis.repos;

import com.kursinis.springkursinislaboratorinis.model.Warehouse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WarehouseRepository extends JpaRepository<Warehouse, Integer> {
}
