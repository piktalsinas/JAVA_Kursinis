package com.kursinis.springkursinislaboratorinis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringKursinisLaboratorinisApplicationTests {

    @Test
    void contextLoads() {
    }

}
