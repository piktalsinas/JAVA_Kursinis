package com.coursework.kursinislaboratorinis.model;

public enum ProductType {
    BAKEDPRODUCTS, OTHER, CANDY;

}