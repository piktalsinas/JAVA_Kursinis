package com.coursework.kursinislaboratorinis.fxControllers;

import com.coursework.kursinislaboratorinis.hibernateControllers.CustomHib;
import com.coursework.kursinislaboratorinis.hibernateControllers.UserHib;
import com.coursework.kursinislaboratorinis.model.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import org.hibernate.Hibernate;


import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

public class MainShopController implements Initializable {


    public ListView<Product> productList;
    public ListView commentListField;
    public ListView<User> usersList;
    public Button deleteUser;
    public Button editUser;
    public ListView warehouseList;
    public Tab warehouseTab;
    public Button deleteWarehouse;
    public Button insertWarehouse;
    public TextField addressWarehouseField;
    public TextField titleWarehouseField;
    public Tab productsTab;
    public Tab usersTab;
    public Tab reviewsTab;
    public Button editWarehouse;
    public ComboBox<ProductType> productType;
    public TextField productTitleField;
    public TextField productDescriptionField;
    public Button insertProduct;
    public Button updateProduct;
    public Button deleteProduct;
    public DatePicker bakedDatePicker;
    public TextField sugarPropField;
    public TextField materialField;
    public TextField weightField;
    public Button addToCartBtn;
    public ListView cartList;
    public ListView paidList;
    public Button payCartBtn;
    public Tab ordersTab;
    public Button deleteFromCartBtn;
    public Tab productsCartsList;
    public ListView replyBodyField;
    public ListView productsReviewList;
    public Button loadCommentsBtn;
    public Button replyOnReviewBtn;
    public ListView repliesList;
    public Button createReviewBtn;
    public Tab allOrdersTab;
    public ComboBox<ProductType> ordersByType;
    public ComboBox<String> ordersByName;
    public ListView filteredList;
    public Button loadAllBtn;
    @FXML
    public ComboBox<String> orderByCustomer;
    public ComboBox desAscOrder;
    public Button filterBtn;
    private List<Customer> customerList;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        customHib = new CustomHib(entityManagerFactory);
        loadTabValues();
        customHib = new CustomHib(entityManagerFactory);
        productType.getItems().addAll(ProductType.values());
        deleteFromCartBtn.setOnAction(this::deleteFromCartList);

        ordersByType.getItems().addAll(ProductType.values());
        ordersByType.setOnAction(this::updateOrdersByName);

        desAscOrder.getItems().addAll("Newest", "Latest");


    }




    private void updateOrdersByName(ActionEvent event) {
        ordersByName.getItems().clear();

        ProductType selectedProductType = ordersByType.getSelectionModel().getSelectedItem();

        if (selectedProductType != null) {
            List<String> productNames = customHib.getProductNamesByType(selectedProductType);

            if (!productNames.isEmpty()) {
                ordersByName.getItems().addAll(productNames);
            } else {
                System.out.println("No product names found for the selected type: " + selectedProductType);
            }
        } else {
            System.out.println("No product type selected.");
        }
    }




    private EntityManagerFactory entityManagerFactory;
    private User currentUser;
    private CustomHib customHib;

    public void setData(EntityManagerFactory entityManagerFactory, User currentUser) {
        this.entityManagerFactory = entityManagerFactory;
        this.currentUser = currentUser;
        customHib = new CustomHib(entityManagerFactory);
    }


    public void loadTabValues() {

        if (usersTab.isSelected()) {
            loadUserData();
        } else if (warehouseTab.isSelected()) {
            loadWarehouseList();
        } else if (productsTab.isSelected()) {
            loadProductList();
        } else if (ordersTab.isSelected()) {
            loadPaidData();
        } else if(reviewsTab.isSelected()) {
            loadProductReviewList();
        }


    }

    private void loadProductReviewList() {
        productsReviewList.getItems().clear();
        productsReviewList.getItems().addAll(customHib.getAllRecords(Product.class));
    }

    private void loadPaidData() {
        Customer currentCustomer = getCurrentCustomer();

        if (currentCustomer != null) {
            List<Cart> cartItems = customHib.getCartItemsByCustomer(currentCustomer);
            ObservableList<Product> paidProducts = FXCollections.observableArrayList();

            for (Cart cartItem : cartItems) {
                paidProducts.add(cartItem.getProduct());
            }

            if (paidList != null) {
                paidList.setItems(paidProducts);
                System.out.println("Paid data loaded successfully.");
            } else {
                System.out.println("paidList is null.");
            }
        } else {
            System.out.println("No current customer found.");
        }
    }

    private UserHib userHib;


    private void loadUserData() {

        userHib = new UserHib(entityManagerFactory);
        List<Customer> customers = userHib.getAllCustomers();
        List<Employee> employees = userHib.getAllEmployees();
        ObservableList<User> users = FXCollections.observableArrayList();
        users = FXCollections.observableArrayList();
        users.addAll(customers);
        users.addAll(employees);

        if (usersList != null) {
            usersList.setItems(users);
            usersList.setCellFactory(param -> new ListCell<User>() {
                @Override
                protected void updateItem(User user, boolean empty) {
                    super.updateItem(user, empty);

                    if (empty || user == null) {
                        setText(null);
                    } else {
                        setText(user.toString()); // Customize this based on your User class
                    }
                }
            });
            usersList.getSelectionModel().selectedItemProperty().addListener(
                    (observable, oldValue, newValue) -> {
                    });
            System.out.println("User data loaded successfully.");
        } else {
            System.out.println("usersList is null.");
        }

    }


    public void editUser() {
        User selectedUser = usersList.getSelectionModel().getSelectedItem();

        if (selectedUser != null) {
            if (userHib.isEmployee(currentUser)) {
                openEditUserDialog(selectedUser);
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Only employees can edit user information.", ButtonType.OK);
                alert.showAndWait();
            }
        } else {
            System.out.println("Please select a user to edit.");
        }
    }

    private void openEditUserDialog(User user) {
        TextField nameTextField = new TextField(user.getName());
        TextField surnameTextField = new TextField(user.getSurname());
        TextField loginTextField = new TextField(user.getLogin());
        TextField passwordTextField = new TextField(user.getPassword());

        Button saveButton = new Button("Save");
        saveButton.setOnAction(event -> {
            user.setName(nameTextField.getText());
            user.setSurname(surnameTextField.getText());
            user.setLogin(loginTextField.getText());
            user.setPassword(passwordTextField.getText());

            customHib.update(user);
            // Refresh the user data in the ListView
            loadUserData();
        });

        usersList.setCellFactory(param -> new ListCell<User>() {
            @Override
            protected void updateItem(User user, boolean empty) {
                super.updateItem(user, empty);

                if (empty || user == null) {
                    setText(null);
                } else {
                    setText(null);
                    VBox vbox = new VBox(
                            new Label("Name:"),
                            nameTextField,
                            new Label("Surname:"),
                            surnameTextField,
                            new Label("Login:"),
                            loginTextField,
                            new Label("Password:"),
                            passwordTextField,
                            saveButton
                    );
                    setGraphic(vbox); // Use setGraphic to display input controls
                }
            }
        });

        usersList.getSelectionModel().select(user);
    }


    public void deleteUser() {
        User selectedUser = usersList.getSelectionModel().getSelectedItem();

        if (selectedUser != null) {
            if (userHib.isEmployee(currentUser)) {
                customHib.delete(User.class, selectedUser.getId());
                loadUserData();
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Only employees can delete user information.", ButtonType.OK);
                alert.showAndWait();
            }
        } else {
            System.out.println("Please select a user to delete.");
        }
    }

    private void loadWarehouseList() {
        if (userHib.isEmployee(currentUser)) {
            warehouseList.getItems().clear();
            warehouseList.getItems().addAll(customHib.getAllRecords(Warehouse.class));
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Only employees can view warehouse information.", ButtonType.OK);
            alert.showAndWait();
        }
    }

    public void deleteWarehouse(ActionEvent actionEvent) {

        Warehouse selectedWarehouse = (Warehouse) warehouseList.getSelectionModel().getSelectedItem();
        Warehouse warehouse = customHib.getEntityById(Warehouse.class, selectedWarehouse.getId());
        customHib.delete(Warehouse.class, selectedWarehouse.getId());
        loadWarehouseList();

    }

    public void insertWarehouse(ActionEvent actionEvent) {

        customHib.create(new Warehouse(titleWarehouseField.getText(), addressWarehouseField.getText()));
        loadWarehouseList();

    }

    public void editWarehouse() {
        Warehouse selectedWarehouse = (Warehouse) warehouseList.getSelectionModel().getSelectedItem();

        if (selectedWarehouse != null) {
            openEditWarehouseDialog(selectedWarehouse);
        } else {
            System.out.println("Please select a warehouse to edit.");
        }

    }

    private void openEditWarehouseDialog(Warehouse warehouse) {
        TextField titleTextField = new TextField(warehouse.getTitle());
        TextField addressTextField = new TextField(warehouse.getAddress());


        Button saveButton = new Button("Save");
        saveButton.setOnAction(event -> {
            warehouse.setTitle(titleTextField.getText());
            warehouse.setAddress(addressTextField.getText());


            customHib.update(warehouse);
            loadWarehouseData();
        });

        warehouseList.setCellFactory(param -> new ListCell<Warehouse>() {
            @Override
            protected void updateItem(Warehouse warehouse, boolean empty) {
                super.updateItem(warehouse, empty);

                if (empty || warehouse == null) {
                    setText(null);
                } else {
                    setText(null);
                    VBox vbox = new VBox(
                            new Label("Name of Warehouse:"),
                            titleTextField,
                            new Label("address:"),
                            addressTextField,
                            saveButton
                    );
                    setGraphic(vbox);
                }
            }
        });

        warehouseList.getSelectionModel().select(warehouse);
    }


    public void loadWarehouseData() {
        Warehouse selectedWarehouse = (Warehouse) warehouseList.getSelectionModel().getSelectedItem();
        titleWarehouseField.setText(selectedWarehouse.getTitle());
        addressWarehouseField.setText(selectedWarehouse.getAddress());
    }

    //////////////////////////////////////////////////////////////////////
    public void createReview(ActionEvent actionEvent) {
        Object selectedItem = productsReviewList.getSelectionModel().getSelectedItem();

        if (selectedItem instanceof Product) {
            Product selectedProduct = (Product) selectedItem;

            if (currentUser instanceof Customer || currentUser instanceof Employee) {
                User user = (User) currentUser;

                TextInputDialog dialog = new TextInputDialog();
                dialog.setTitle("Create Review");
                dialog.setHeaderText("Enter your review for the product: " + selectedProduct.getTitle());
                dialog.setContentText("Review:");

                Optional<String> result = dialog.showAndWait();

                result.ifPresent(reviewBody -> {
                    Review review = new Review();
                    review.setProduct(selectedProduct);

                    if (currentUser instanceof Customer) {
                        review.setCustomer((Customer) user);
                    } else if (currentUser instanceof Employee) {
                        review.setEmployee((Employee) user);
                    }

                    review.setReviewBody(reviewBody);

                    customHib.create(review);
                    System.out.println("Review created successfully.");
                });
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Only customers and employees can create reviews.", ButtonType.OK);
                alert.showAndWait();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Please select a product to review.", ButtonType.OK);
            alert.showAndWait();
        }
    }


    //////////////////////////////////////////////////////////////////////


    public void enableProductFields(ActionEvent actionEvent) {
        if (productType.getSelectionModel().getSelectedItem() == ProductType.BAKEDPRODUCTS) {
            productTitleField.setDisable(false);
            bakedDatePicker.setDisable(false);
            sugarPropField.setDisable(true);
            weightField.setDisable(true);
            productDescriptionField.setDisable(false);
            materialField.setDisable(true);
        } else if (productType.getSelectionModel().getSelectedItem() == ProductType.CANDY) {
            productTitleField.setDisable(false);
            bakedDatePicker.setDisable(true);
            sugarPropField.setDisable(false);
            weightField.setDisable(false);
            productDescriptionField.setDisable(false);
            materialField.setDisable(true);
        } else {
            productTitleField.setDisable(false);
            bakedDatePicker.setDisable(true);
            sugarPropField.setDisable(true);
            weightField.setDisable(false);
            productDescriptionField.setDisable(false);
            materialField.setDisable(false);
        }
    }

    private void loadProductList() {
        productList.getItems().clear();
        productList.getItems().addAll(customHib.getAllRecords(Product.class));

    }

    public void insertProduct(ActionEvent actionEvent) {
        if (userHib.isEmployee(currentUser)) {
            if (productType.getSelectionModel().getSelectedItem() == ProductType.BAKEDPRODUCTS) {
                customHib.create(new BakedProducts(productTitleField.getText(), productDescriptionField.getText(), bakedDatePicker.getValue()));
            } else if (productType.getSelectionModel().getSelectedItem() == ProductType.CANDY) {
                customHib.create(new Candy(productTitleField.getText(), productDescriptionField.getText(), sugarPropField.getText(), weightField.getText()));
            } else {
                customHib.create(new Other(productTitleField.getText(), productDescriptionField.getText(), weightField.getText(), materialField.getText()));
            }
            loadProductList();
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Only employees can insert new products.", ButtonType.OK);
            alert.showAndWait();
        }
    }

    public void updateProduct(ActionEvent actionEvent) {
    }

    public void deleteProduct(ActionEvent actionEvent) {
        if (userHib.isEmployee(currentUser)) {
            Product selectedProduct = (Product) productList.getSelectionModel().getSelectedItem();
            Product product = customHib.getEntityById(Product.class, selectedProduct.getId());
            customHib.delete(Product.class, selectedProduct.getId());
            loadProductList();
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Only employees can delete products.", ButtonType.OK);
            alert.showAndWait();
        }

    }
    //////////////////////////////////////////////////////////////////////////////////////

    public void addToCart(ActionEvent actionEvent) {
        if (currentUser instanceof Customer) {
            Customer currentCustomer = (Customer) currentUser;

            Product selectedProduct = productList.getSelectionModel().getSelectedItem();

            if (selectedProduct != null) {
                cartList.getItems().add(selectedProduct);
                System.out.println("Product added to cart: " + selectedProduct.getTitle());
            } else {
                System.out.println("Please select a product to add to the cart.");
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Only customers can have a cart!", ButtonType.OK);
            alert.showAndWait();
        }
    }


    public void payCart(ActionEvent actionEvent) {
        Customer currentCustomer = getCurrentCustomer();

        Iterator<Object> iterator = cartList.getItems().iterator();
        while (iterator.hasNext()) {
            Object item = iterator.next();

            if (item instanceof Product) {
                Product product = (Product) item;

                Cart cart = new Cart();
                cart.setProduct(product);
                cart.setProductName(product.getTitle());
                cart.setCustomer(currentCustomer);

                customHib.create(cart);

                iterator.remove();
            }
        }

        System.out.println("Cart paid successfully.");

    }

    public Customer getCurrentCustomer() {
        if (currentUser instanceof Customer) {
            return (Customer) currentUser;
        } else {
            return null;
        }
    }
    public Employee getCurrentEmployee() {
        if (currentUser instanceof Employee) {
            return (Employee) currentUser;
        } else {
            return null;
        }
    }

    public void deleteFromCartList(ActionEvent actionEvent) {
        if (currentUser instanceof Customer) {
            Customer currentCustomer = (Customer) currentUser;

            Object selectedItem = cartList.getSelectionModel().getSelectedItem();

            if (selectedItem instanceof Product) {
                Product selectedProduct = (Product) selectedItem;
                cartList.getItems().remove(selectedProduct);
                System.out.println("Product removed from cart: " + selectedProduct.getTitle());
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Please select a product to remove from the cart.", ButtonType.OK);
                alert.showAndWait();
                System.out.println("Please select a product to remove from the cart.");
            }
        }
    }

    public void submitReview(ActionEvent actionEvent) {
        Customer currentCustomer = getCurrentCustomer();
        Object selectedItem = paidList.getSelectionModel().getSelectedItem();

        if (currentCustomer != null && selectedItem instanceof Product) {
            Product selectedProduct = (Product) selectedItem;

            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Submit Review");
            dialog.setHeaderText("Enter your review for the product: " + selectedProduct.getTitle());
            dialog.setContentText("Review:");

            Optional<String> result = dialog.showAndWait();

            result.ifPresent(reviewBody -> {
                Review review = new Review();
                review.setProduct(selectedProduct);
                review.setCustomer(currentCustomer);
                review.setReviewBody(reviewBody);

                customHib.create(review);
                System.out.println("Review submitted successfully.");
            });
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Please select a product before submitting a review", ButtonType.OK);
            alert.showAndWait();
            System.out.println("Please select a customer and a product before submitting a review.");
        }
    }



    public void loadComments(ActionEvent actionEvent) {
        Object selectedItem = productsReviewList.getSelectionModel().getSelectedItem();

        if (selectedItem instanceof Product) {
            Product selectedProduct = (Product) selectedItem;

            Hibernate.initialize(selectedProduct.getReviews());

            List<Review> reviews = selectedProduct.getReviews();
            ObservableList<String> comments = FXCollections.observableArrayList();

            for (Review review : reviews) {
                Hibernate.initialize(review.getReplies());

                String commentWithUser = getCommentStructure(review);
                comments.add(commentWithUser);

                List<Review> replies = review.getReplies();
                for (Review reply : replies) {
                    String replyWithUser = getReplyStructure(reply);
                    comments.add(replyWithUser);
                }
            }

            commentListField.setItems(comments);
            System.out.println("Comments loaded successfully.");
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Select a product", ButtonType.OK);
            alert.showAndWait();
        }
    }


    private String getCommentStructure(Review review) {
        if (review.getEmployee() != null) {
            return "(employee) " + review.getUserLogin() + ": " + review.getReviewBody();
        } else {
            return review.getUserLogin() + ": " + review.getReviewBody();
        }
    }

    private String getReplyStructure(Review review) {
        if (review.getEmployee() != null) {
            return "    (employee) " + review.getUserLogin() + "'s Reply: " + review.getReviewBody();
        } else {
            return "    " + review.getUserLogin() + "'s Reply: " + review.getReviewBody();
        }
    }

    public void replyOnReview(ActionEvent actionEvent) {
        Object selectedItem = productsReviewList.getSelectionModel().getSelectedItem();

        if (selectedItem instanceof Product) {
            Product selectedProduct = (Product) selectedItem;

            Object selectedReviewItem = commentListField.getSelectionModel().getSelectedItem();

            if (selectedReviewItem instanceof String) {
                String originalReviewText = (String) selectedReviewItem;
                String originalReviewBody = extractReviewBody(originalReviewText);

                TextInputDialog dialog = new TextInputDialog();
                dialog.setTitle("Reply to Review");
                dialog.setHeaderText("Enter your reply to the following review:\n" + originalReviewText);
                dialog.setContentText("Reply:");

                Optional<String> result = dialog.showAndWait();

                result.ifPresent(replyBody -> {
                    Review replyReview = new Review();
                    replyReview.setProduct(selectedProduct);

                    if (getCurrentEmployee() != null) {
                        replyReview.setEmployee(getCurrentEmployee());
                    } else {
                        replyReview.setCustomer(getCurrentCustomer());
                    }

                    replyReview.setReviewBody(replyBody);

                    List<Review> originalReviews = selectedProduct.getReviews();
                    Review originalReview = findReviewByBody(originalReviews, originalReviewBody);

                    if (originalReview != null) {
                        if (originalReview.getOriginalReview() == null) {
                            replyReview.setOriginalReview(originalReview);
                        }

                        customHib.create(replyReview);
                        System.out.println("Reply submitted successfully.");
                    } else {
                        Alert alert = new Alert(Alert.AlertType.WARNING, "Original review not found.", ButtonType.OK);
                        alert.showAndWait();
                    }
                });
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Please, select a review to reply.", ButtonType.OK);
                alert.showAndWait();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Select a product before replying", ButtonType.OK);
            alert.showAndWait();
        }
    }

    private Review findReviewByBody(List<Review> reviews, String reviewBody) {
        for (Review review : reviews) {
            if (review.getReviewBody().equals(reviewBody)) {
                return review;
            }
        }
        return null;
    }

    private String extractReviewBody(String reviewWithUser) {
        int separatorIndex = reviewWithUser.indexOf(": ");
        if (separatorIndex != -1 && separatorIndex + 2 < reviewWithUser.length()) {
            return reviewWithUser.substring(separatorIndex + 2);
        }
        return reviewWithUser;
    }


    public void loadAllOrders(ActionEvent actionEvent) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        try {
            entityManager.getTransaction().begin();

            Query query = entityManager.createQuery("SELECT c FROM Cart c");
            List<Cart> cartItems = query.getResultList();

            ObservableList<Cart> cartItemsObservableList = FXCollections.observableArrayList(cartItems);
            filteredList.setItems(cartItemsObservableList);

            entityManager.getTransaction().commit();
        } catch (Exception e) {
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            entityManager.close();
        }
    }

    public void filterOrders(ActionEvent actionEvent) {
        if (userHib.isEmployee(currentUser)) {
        ObservableList<Cart> cartItemsObservableList = FXCollections.observableArrayList();

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        try {
            entityManager.getTransaction().begin();

            CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
            CriteriaQuery<Cart> criteriaQuery = criteriaBuilder.createQuery(Cart.class);
            Root<Cart> cartRoot = criteriaQuery.from(Cart.class);
            Join<Cart, Product> productJoin = cartRoot.join("product");

            if (ordersByType.getValue() != null) {
                criteriaQuery.where(criteriaBuilder.equal(productJoin.type(), getTypeClass(ordersByType.getValue())));
            }

            if (ordersByName.getValue() != null) {
                criteriaQuery.where(criteriaBuilder.equal(productJoin.get("title"), ordersByName.getValue()));
            }

            Order sortOrder;
            Object selectedOrder = desAscOrder.getValue();
            if ("Newest".equals(selectedOrder)) {
                sortOrder = criteriaBuilder.desc(cartRoot.get("id"));
            } else if ("Latest".equals(selectedOrder)) {
                sortOrder = criteriaBuilder.asc(cartRoot.get("id"));
            } else {
                sortOrder = null;
            }

            if (sortOrder != null) {
                criteriaQuery.orderBy(sortOrder);
            }

            TypedQuery<Cart> query = entityManager.createQuery(criteriaQuery);
            List<Cart> cartItems = query.getResultList();

            cartItemsObservableList.addAll(cartItems);
            filteredList.setItems(cartItemsObservableList);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            entityManager.close();
        }
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Only employees can view order history.", ButtonType.OK);
            alert.showAndWait();
        }
    }

    private Class<? extends Product> getTypeClass(ProductType productType) {
        return customHib.getTypeClassName(productType);
    }
}
