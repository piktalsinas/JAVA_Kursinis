package com.coursework.kursinislaboratorinis.hibernateControllers;

import com.coursework.kursinislaboratorinis.model.*;
import jakarta.persistence.*;
import jakarta.persistence.criteria.*;
import org.hibernate.Session;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CustomHib extends GenericHib {

    private EntityManagerFactory entityManagerFactory;

    public CustomHib(EntityManagerFactory entityManagerFactory) {
        super(entityManagerFactory);

    }



    public User getUserByCredentials(String login, String password) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery<User> query = cb.createQuery(User.class);
            Root<User> root = query.from(User.class);
            query.select(root).where(cb.and(cb.like(root.get("login"), login), cb.like(root.get("password"), password)));
            Query q = em.createQuery(query);
            return (User) q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            if (em != null) em.close();
        }
    }

    public List<Cart> getCartItemsByCustomer(Customer customer) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            String jpql = "SELECT c FROM Cart c WHERE c.customer = :customer";
            TypedQuery<Cart> query = em.createQuery(jpql, Cart.class);
            query.setParameter("customer", customer);
            return query.getResultList();
        } finally {
            if (em != null) em.close();
        }
    }

    public List<String> getProductNamesByType(ProductType productType) {
        EntityManager em = null;
        try {
            em = getEntityManager();

            String jpql = "SELECT p.title FROM Product p WHERE TYPE(p) = :productType";
            TypedQuery<String> query = em.createQuery(jpql, String.class);
            query.setParameter("productType", getTypeClassName(productType));
            return query.getResultList();
        } finally {
            if (em != null) em.close();
        }
    }

    public Class<? extends Product> getTypeClassName(ProductType productType) {
        switch (productType) {
            case BAKEDPRODUCTS:
                return BakedProducts.class;
            case CANDY:
                return Candy.class;
            case OTHER:
                return Other.class;
            default:
                throw new IllegalArgumentException("Unsupported product type: " + productType);
        }
    }





}
