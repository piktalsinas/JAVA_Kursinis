package com.coursework.kursinislaboratorinis.model;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class OrderTableParameters {
    private final SimpleIntegerProperty orderId;
    private final SimpleStringProperty productName;
    private final SimpleStringProperty customerName;

    public OrderTableParameters(int orderId, String productName, String customerName) {
        this.orderId = new SimpleIntegerProperty(orderId);
        this.productName = new SimpleStringProperty(productName);
        this.customerName = new SimpleStringProperty(customerName);
    }

    public int getOrderId() {
        return orderId.get();
    }

    public String getProductName() {
        return productName.get();
    }

    public String getCustomerName() {
        return customerName.get();
    }
}
