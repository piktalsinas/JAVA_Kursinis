package com.coursework.kursinislaboratorinis.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
public class Product implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;
    String title;
    String description;
    @ManyToOne
    Warehouse warehouse;
    @ManyToOne
    Cart cart;

    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<Review> reviews = new ArrayList<>();
    public Product(String title, String description) {
        this.title = title;
        this.description = description;
    }

    public void addReview(Review review) {
        reviews.add(review);
        review.setProduct(this);
    }


    public Product(String title, String description, Warehouse warehouse) {
        this.title = title;
        this.description = description;
        this.warehouse = warehouse;
    }

    public String toString() {

        return "Product: " + getTitle() + ", Description: " + getDescription();
    }
}
