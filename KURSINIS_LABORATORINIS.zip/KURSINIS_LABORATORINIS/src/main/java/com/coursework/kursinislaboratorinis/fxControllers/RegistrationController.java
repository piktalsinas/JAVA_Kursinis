package com.coursework.kursinislaboratorinis.fxControllers;

import com.coursework.kursinislaboratorinis.hibernateControllers.UserHib;
import com.coursework.kursinislaboratorinis.model.Customer;
import com.coursework.kursinislaboratorinis.model.Employee;
import com.coursework.kursinislaboratorinis.model.User;
import jakarta.persistence.EntityManagerFactory;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
//import utils.DatabaseUtils;
//
//import java.sql.Connection;
//import java.sql.Date;
//import java.sql.PreparedStatement;

public class RegistrationController {

    @FXML
    public TextField loginField;
    @FXML
    public PasswordField passwordField;
    @FXML
    public PasswordField repeatPasswordField;
    @FXML
    public TextField nameField;
    @FXML
    public TextField surnameField;
    @FXML
    public RadioButton customerCheckbox;
    @FXML
    public ToggleGroup userType;
    @FXML
    public RadioButton managerCheckbox;
    @FXML
    public TextField addressField;
    @FXML
    public TextField cardNoField;
    @FXML
    public DatePicker birthDateField;
    @FXML
    public TextField employeeIdField;
    @FXML
    public TextField medCertificateField;
    @FXML
    public DatePicker employmentDateField;
    @FXML
    public CheckBox isAdminCheck;

    private EntityManagerFactory entityManagerFactory;
    private UserHib userHib;

    public void setData(EntityManagerFactory entityManagerFactory) {
        this.entityManagerFactory = entityManagerFactory;
        userHib = new UserHib(entityManagerFactory);
    }


    public void createUser() {
        userHib = new UserHib(entityManagerFactory);


        String login = loginField.getText();
        String password = passwordField.getText();
        String repeatPassword = repeatPasswordField.getText();
        LocalDate birthDate = birthDateField.getValue();
        String name = nameField.getText();
        String surname = surnameField.getText();

        if (!password.equals(repeatPassword)) {
            showAlert("Passwords do not match");
            return;
        }

        if (customerCheckbox.isSelected()) {
            if (loginField.getText().isEmpty() ||
                    passwordField.getText().isEmpty() ||
                    repeatPasswordField.getText().isEmpty() ||
                    birthDateField.getValue() == null ||
                    nameField.getText().isEmpty() ||
                    surnameField.getText().isEmpty()) {
                showAlert("Please fill in all required fields");
            }else {
                User user = new Customer(login, password, birthDate, name, surname);
                userHib.createUser(user);
            }
        } else if (managerCheckbox.isSelected()) {
            if( loginField.getText().isEmpty() ||
                    passwordField.getText().isEmpty() ||
                    repeatPasswordField.getText().isEmpty() ||
                    birthDateField.getValue() == null ||
                    nameField.getText().isEmpty() ||
                    surnameField.getText().isEmpty() ||
                    employmentDateField.getValue() == null) {
                showAlert("Please fill in all required fields");
            }else {
                LocalDate employmentDate = employmentDateField.getValue();
                User user = new Employee(login, password, birthDate, name, surname, employmentDate);
                userHib.createUser(user);
            }
        }


    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void returnToLogin() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getClassLoader().getResource("login.fxml"));
        Parent parent = fxmlLoader.load();

        Scene scene = new Scene(parent);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }
}
