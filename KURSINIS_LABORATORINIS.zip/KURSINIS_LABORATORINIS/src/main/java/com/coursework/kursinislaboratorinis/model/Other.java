package com.coursework.kursinislaboratorinis.model;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Other extends Product{
    private String weight;
    private String material;

    public Other(String title, String description, String weight, String material) {
        super(title, description);
        this.weight = weight;
        this.material = material;
    }
}
