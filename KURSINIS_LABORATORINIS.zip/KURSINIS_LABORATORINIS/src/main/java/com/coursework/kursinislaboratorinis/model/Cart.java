package com.coursework.kursinislaboratorinis.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

//    @ManyToOne
//    private Customer customer;
    //(cascade = CascadeType.ALL)
    @ManyToOne
    private Customer customer;
    @ManyToOne
    private Product product;

    private String productName;



    public Cart(int id, Customer customer) {
        this.id = id;
        this.customer = customer;

    }
    @Override
    public String toString() {
        return " " +
                "id=" + id +
                ", product=" + product +
                ", productName='" + productName + '\'' +
                ", customer=" + customer +
                ' ';
    }

    public int getProductId() {
        return product.getId();
    }

    public String getProductName() {
        return product.getTitle();
    }

    public int getCustomerId() {
        return customer.getId();
    }


}
