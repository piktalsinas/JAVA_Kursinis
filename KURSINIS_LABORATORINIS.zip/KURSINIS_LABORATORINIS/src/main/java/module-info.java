module com.coursework.kursinismavenbuild {
    requires javafx.controls;
    requires javafx.fxml;
    requires lombok;
    requires java.sql;
    requires org.hibernate.orm.core;
    requires jakarta.persistence;


    opens com.coursework.kursinislaboratorinis to javafx.fxml;
    exports com.coursework.kursinislaboratorinis;
    opens com.coursework.kursinislaboratorinis.fxControllers to javafx.fxml;
    exports com.coursework.kursinislaboratorinis.fxControllers to javafx.fxml;
    opens com.coursework.kursinislaboratorinis.model to org.hibernate.orm.core;
}