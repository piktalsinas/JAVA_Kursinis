package com.example.kursinisbakery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.kursinisbakery.helpers.Constants;
import com.example.kursinisbakery.helpers.Rest;
import com.example.kursinisbakery.model.Product;
import com.example.kursinisbakery.model.Warehouse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ProductsActivity extends AppCompatActivity {

    private ListView productListView;

    private List<Product> productList;
    private List<Product> cartList;
    private ListView cartListView;
    private Button addToCartBtn;
    private Button goToWarehouseBtn;
    private TextView productIdTextField;
    private Button updateProductBtn;
    private Button goToUpdateUserBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products);

        cartListView = findViewById(R.id.cartListView);
        productListView = findViewById(R.id.productListView);
        productIdTextField = findViewById(R.id.productIdTextField);
        addToCartBtn = findViewById(R.id.addToCartBtn);
       // goToWarehouseBtn = findViewById(R.id.goToWarehouseBtn);
       // updateProductBtn = findViewById(R.id.updateProductBtn);
        goToUpdateUserBtn = findViewById(R.id.goToUpdateUserBtn);

        productList = new ArrayList<>();
        cartList = new ArrayList<>();

        new GetAllProducts().execute();

        addToCartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String productIdString = productIdTextField.getText().toString();
                if (!productIdString.isEmpty()) {
                    int productId = Integer.parseInt(productIdString);
                    new GetProductById().execute(productId);
                }
            }
        });

//        goToWarehouseBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(ProductsActivity.this, WarehouseActivity.class);
//                startActivity(intent);
//            }
//        });

//        updateProductBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                updateProduct();
//            }
//        });

        goToUpdateUserBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProductsActivity.this, UserChangeActivity.class);
                startActivity(intent);
            }
        });


    }

    private class GetAllProducts extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            return Rest.sendGet(Constants.GET_ALL_PRODUCTS);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            try {
                JSONArray jsonArray = new JSONArray(result);

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    int productId = jsonObject.getInt("id");
                    String productTitle = jsonObject.getString("title");
                    String productDescription = jsonObject.getString("description");


                    Product productInfo = new Product(productId, productTitle, productDescription);
                    productList.add(productInfo);
                }

                updateUI();

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void updateUI() {
        List<String> productDetails = new ArrayList<>();

        for (Product product : productList) {
            productDetails.add(product.getId() + " " + product.getTitle() + ": " + product.getDescription());
        }

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(
                ProductsActivity.this,
                android.R.layout.simple_list_item_1,
                productDetails
        );

        productListView.setAdapter(arrayAdapter);
    }

    private class GetProductById extends AsyncTask<Integer, Void, String> {
        @Override
        protected String doInBackground(Integer... params) {
            int productId = params[0];
            String url = Constants.GET_PRODUCT_BY_ID + productId;
            return Rest.sendGet(url);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            try {
                JSONObject jsonObject = new JSONObject(result);
                int productId = jsonObject.getInt("id");
                String productTitle = jsonObject.getString("title");
                String productDescription = jsonObject.getString("description");

                Product productInfo = new Product(productId, productTitle, productDescription);
                cartList.add(productInfo);

                updateCart();

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void updateCart() {
        List<String> cartDetails = new ArrayList<>();

        for (Product product : cartList) {
            cartDetails.add(product.getId() + " " + product.getTitle() + ": " + product.getDescription());
        }

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(
                ProductsActivity.this,
                android.R.layout.simple_list_item_1,
                cartDetails
        );

        cartListView.setAdapter(arrayAdapter);
    }

//    private void updateProduct() {
//        String productIdString = productIdTextField.getText().toString();
//        if (!productIdString.isEmpty()) {
//            int productId = Integer.parseInt(productIdString);
//
//            EditText updatedTitleEditText = findViewById(R.id.updatedTitleEditText);
//            EditText updatedDescriptionEditText = findViewById(R.id.updatedDescriptionEditText);
//
//            String updatedTitle = updatedTitleEditText.getText().toString();
//            String updatedDescription = updatedDescriptionEditText.getText().toString();
//
//            Product updatedProduct = new Product(productId, updatedTitle, updatedDescription);
//
//            new UpdateProductTask().execute(updatedProduct);
//        }
//    }


//    private class UpdateProductTask extends AsyncTask<Product, Void, String> {
//        @Override
//        protected String doInBackground(Product... products) {
//            Product product = products[0];
//            String urlStr = Constants.UPDATE_PRODUCT;
//            try {
//                JSONObject jsonProduct = new JSONObject();
//                jsonProduct.put("id", product.getId());
//                jsonProduct.put("title", product.getTitle());
//                jsonProduct.put("description", product.getDescription());
//
//                String productJson = jsonProduct.toString();
//
//                return Rest.sendPut(urlStr, productJson);
//            } catch (Exception e) {
//                e.printStackTrace();
//                return "Error updating product: " + e.getMessage();
//            }
//        }
//
//        @Override
//        protected void onPostExecute(String result) {
//            super.onPostExecute(result);
//
//        }
//    }
}
