package com.example.kursinisbakery.model;

public enum ProductType {
    BAKEDPRODUCTS, OTHER, CANDY;

}