package com.example.kursinisbakery.model;

import java.time.LocalDate;

public class Employee extends User {

//    private String employeeId;
//    private String medCertificate;
    private LocalDate employmentDate;
   // private boolean isAdmin;

    private Warehouse worksInWarehouse;

    public Employee(int id, String login, String password, LocalDate birthDate, String name, String surname, LocalDate employmentDate) {
        super(id, login, password, birthDate, name, surname);
        this.employmentDate=employmentDate;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "login='" + login + '\'' +
                ", password='" + password + '\'' +
                ", birthdate='" + birthDate + '\'' +
                ", name='" + name + '\'' +
                ", surname=" + surname + '\'' +
                ", employmentDate=" + employmentDate +
                '}';
    }
}
