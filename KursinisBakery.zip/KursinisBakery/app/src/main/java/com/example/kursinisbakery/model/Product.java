package com.example.kursinisbakery.model;


import java.io.Serializable;

public class Product implements Serializable {

    //private String sugarProps;
    int id;
    String title;
    String description;

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public Product(int id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
    }

//
//    public Product(String title, String description) {
//        this.title = title;
//        this.description = description;
//        //this.warehouse = warehouse;
//    }
}
