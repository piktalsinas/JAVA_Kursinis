package com.example.kursinisbakery.model;


import java.io.Serializable;
import java.time.LocalDate;

public class User implements Serializable {

    protected int id;
  //  @Column(unique = true)
    String login;
    String password;
    LocalDate birthDate;
    String name;
    String surname;
//    @OneToMany(mappedBy = "user", cascade = {CascadeType.PERSIST, CascadeType.MERGE})
//    @LazyCollection(LazyCollectionOption.FALSE)
//    List<Review> myComments;


    public User( int id, String login, String password, LocalDate birthDate, String name, String surname) {
        this.id= id;
        this.login = login;
        this.password = password;
        this.birthDate = birthDate;
        this.name= name;
        this.surname= surname;
    }

    public User(int id, String login, String password, LocalDate birthDate) {
        this.id = id;
        this.login = login;
        this.password = password;
        this.birthDate = birthDate;
    }

    @Override
    public String toString() {
        return "User{" +
                "Id= ' " + id + '\'' +
                "login='" + login + '\'' +
                ", password='" + password + '\'' +
                ", birthdate='" + birthDate + '\'' +
                ", password='" + name + '\'' +
                ", surname='" + surname + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }
}
