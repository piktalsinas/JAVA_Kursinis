package com.example.kursinisbakery.model;


import java.io.Serializable;

public class Warehouse implements Serializable {

    private int id;
    private String title;
    private String address;


    public Warehouse(String title, String address) {
        this.title = title;
        this.address = address;
    }

    @Override
    public String toString() {
        return "Warehouse{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
}
