package com.example.kursinisbakery.model;

import java.time.LocalDate;

public class BakedProducts extends Product {

//    public String toString() {
//
//        return "Product: " + getTitle() + ", Description: " + getDescription();
//    }

    private LocalDate bakedDate;
    private String type = "BakedProducts";

    public BakedProducts(int id,String title, String description, LocalDate bakedDate) {
        super(id, title, description);
        this.bakedDate = bakedDate;
       // this.type = type;
    }

    public String getType() {
        return type;
    }

    public LocalDate getBakedDate() {
        return bakedDate;
    }

//    public BakedProducts(String title, String description, Warehouse warehouse, LocalDate plantDate) {
//        super(title, description, warehouse);
//        this.bakedDate = bakedDate;
//    }
}
