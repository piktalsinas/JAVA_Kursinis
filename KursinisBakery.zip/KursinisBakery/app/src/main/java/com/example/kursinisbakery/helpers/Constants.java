package com.example.kursinisbakery.helpers;

public class Constants {
    //static int id;
    //192.168.160.1 (home)
    // 192.168.96.1 (uni)
    public static final String BASE_URL="http://192.168.68.105:8080";
    public static final String VALIDATE_USER = BASE_URL + "/getUserByCredentials"; //POST
    public static final String GET_ALL_USERS = BASE_URL + "/getAllUsers"; //GET
    public static final String DELETE_USER = BASE_URL + "/deleteUser/"; //DELETE

    public static final String GET_ALL_PRODUCTS = BASE_URL +"/getAllProducts"; //GET
    public static final String GET_PRODUCT_BY_ID = BASE_URL + "/getProductById/"; //GET
    public static final String UPDATE_USER = BASE_URL + "/updateUser"; //PUT
}
