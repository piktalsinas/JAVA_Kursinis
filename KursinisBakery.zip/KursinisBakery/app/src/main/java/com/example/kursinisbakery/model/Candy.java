package com.example.kursinisbakery.model;


public class Candy extends Product {
    private String sugarProps;
    private String weight;
    private String type = "Candy";

    public String getType() {
        return type;
    }

    public Candy(int id,String title, String description, String sugarProps, String weight) {
        super(id, title, description);
        this.sugarProps = sugarProps;
        this.weight = weight;
    }

    public String getSugarProps() {
        return sugarProps;
    }

    public String getWeight() {
        return weight;
    }
}
