package com.example.kursinisbakery;

import static com.example.kursinisbakery.helpers.Constants.UPDATE_USER;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class UserChangeActivity extends AppCompatActivity {

    private EditText editTextNewUsername;
    private EditText editTextNewPassword;
    private Button updateUserBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_change);

        editTextNewUsername = findViewById(R.id.editTextNewUsername);
        editTextNewPassword = findViewById(R.id.editTextNewPassword);
        updateUserBtn = findViewById(R.id.updateUserBtn);

        updateUserBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new UpdateCredentialsTask().execute();
            }
        });
    }

    private class UpdateCredentialsTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            try {

                URL url = new URL(UPDATE_USER);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                try {

                    urlConnection.setRequestMethod("PUT");
                    urlConnection.setRequestProperty("Content-Type", "application/json");

                    String jsonInputString = "{"
                            + "\"login\": \"" + editTextNewUsername.getText().toString() + "\","
                            + "\"password\": \"" + editTextNewPassword.getText().toString() + "\""
                            + "}";

                    urlConnection.setDoOutput(true);
                    urlConnection.getOutputStream().write(jsonInputString.getBytes());

                    BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;

                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    return response.toString();
                } finally {
                    urlConnection.disconnect();
                }
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {

            if (result != null) {

                Toast.makeText(UserChangeActivity.this, "Credentials updated successfully", Toast.LENGTH_SHORT).show();
            } else {

                Toast.makeText(UserChangeActivity.this, "Error updating credentials", Toast.LENGTH_SHORT).show();
            }
        }
    }
}