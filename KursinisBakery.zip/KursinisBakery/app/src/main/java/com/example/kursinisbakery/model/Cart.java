package com.example.kursinisbakery.model;


public class Cart {

    private int id;

}
