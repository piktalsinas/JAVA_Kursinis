package com.example.kursinisbakery.model;


public class Review {

    private int id;
    private String reviewBody;
//    @ManyToOne
//    private User user;
}
