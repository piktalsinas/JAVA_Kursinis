package com.example.kursinisbakery.model;


public class Other extends Product{
    private String weight;
    private String material;
    private String type = "Other";

    public Other(int id,String title, String description, String weight, String material) {
        super(id, title, description);
        this.weight = weight;
        this.material = material;
    }

    public String getType() {
        return type;
    }

    public String getWeight() {
        return weight;
    }

    public String getMaterial() {
        return material;
    }
}
