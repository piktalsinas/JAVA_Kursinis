package com.example.kursinisbakery.model;


import java.time.LocalDate;

public class Customer extends User {


    public Customer(int id,String login, String password, LocalDate birthDate, String name, String surname) {
        super(id, login, password, birthDate, name, surname);
//        this.address = address;
//        this.cardNo = cardNo;
    }



    @Override
    public String toString() {
        return "Customer{" +
                "login='" + login + '\'' +
                ", password='" + password + '\'' +
                ", birthdate='" + birthDate + '\'' +
                ", name='" + name + '\'' +
                ", surname=" + surname +
                '}';
    }


}
