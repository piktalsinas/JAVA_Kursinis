package com.example.kursinisbakery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.kursinisbakery.helpers.Constants;
import com.example.kursinisbakery.helpers.Rest;
import com.example.kursinisbakery.model.User;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class UsersAllActivity extends AppCompatActivity {

    private ListView usersListView;
    private Button deleteUserBtn;
    private Button goToProductsBtn;
    private EditText userIdTextField;

    private String selectedUser;

    private List<User> userList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users_all);

        usersListView = findViewById(R.id.usersListView);
        deleteUserBtn = findViewById(R.id.deleteUserBtn);
        goToProductsBtn = findViewById(R.id.goToProductsBtn);
        userIdTextField = findViewById(R.id.userIdTextField);


        userList = new ArrayList<>();


        new GetAllUsersTask().execute();

        deleteUserBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userIdText = userIdTextField.getText().toString().trim();

                if (!userIdText.isEmpty()) {
                    int userId = Integer.parseInt(userIdText);
                    new DeleteUserTask().execute(userId);
                } else {
                    Toast.makeText(UsersAllActivity.this, "Enter ID", Toast.LENGTH_SHORT).show();
                }
            }
        });

        goToProductsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UsersAllActivity.this, ProductsActivity.class);
                startActivity(intent);
            }
        });


    }

    private class GetAllUsersTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            return Rest.sendGet(Constants.GET_ALL_USERS);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            List<String> userList = new ArrayList<>();

            try {
                JSONArray jsonArray = new JSONArray(result);

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String userInfo = "Id: "  + jsonObject.getInt("id") +
                            ", Login: "  + jsonObject.getString("login") +
                            ", Birthdate: " + jsonObject.getString("birthDate") +
                            ", Name: " + jsonObject.getString("name") +
                            ", Surname: " + jsonObject.getString("surname");
                    userList.add(userInfo);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(
                    UsersAllActivity.this,
                    android.R.layout.simple_list_item_1,
                    userList
            );

            usersListView.setAdapter(arrayAdapter);
            usersListView.setOnItemClickListener((parent, view, position, id) -> {
                selectedUser = userList.get(position);
            });
        }
    }

    private class DeleteUserTask extends AsyncTask<Integer, Void, String> {

        @Override
        protected String doInBackground(Integer... params) {
            int userId = params[0];
            return Rest.sendDelete(Constants.DELETE_USER + userId);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            if (result.equals("user deleted")) {
                // Update the list view after successful deletion
                new GetAllUsersTask().execute();
                Toast.makeText(UsersAllActivity.this, "User deleted successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(UsersAllActivity.this, "Failed to delete user", Toast.LENGTH_SHORT).show();
            }
        }
    }

}